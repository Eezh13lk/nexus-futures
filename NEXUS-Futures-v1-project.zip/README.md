# NEXUS Futures

Separate Android application from the existing TradingBot 3.4.0.

- Application ID: `com.eezh.nexusfutures`
- V1 defaults to PAPER mode.
- GitHub Actions builds a debug APK.
- No Binance credentials belong in this repository.

## Build from phone
1. Upload this project to `Eezh13lk/nexus-futures`.
2. Open the **Actions** tab.
3. Run **Build NEXUS Futures APK**.
4. Download the `NEXUS-Futures-debug` artifact.
5. Install the APK on Android.

This first build is a safe UI/paper-mode foundation. Real Binance execution should be implemented and tested separately before enabling live orders.
